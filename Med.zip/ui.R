library(shinydashboard)
library(shinyjs)
library(plotly)

jscode <- "shinyjs.closeWindow = function() { window.close(); }"

body <- tabItems(
  tabItem(tabName = "dashboard",
          fluidRow(
          tags$head(tags$style(type="text/css", "
             #loadmessage {
               text-align: center;
               font-weight: bold;
               font-size: 100%;
               color: #000000;
               background-color: #ffbb33;
             }
            #bar {
              height: calc(100vh - 80px) !important;}
          ")),
          conditionalPanel(condition="$('html').hasClass('shiny-busy')",icon("refresh","fa-spin fa-fw fa-2x"),
                           tags$div("Loading...",id="loadmessage")
          ),
            box(
              title = "Controls",
              dateInput("date","Date a traiter",value = "2017-11-15",min="2017-08-01",
                        max="2017-12-31"),
              actionButton(inputId = "import", 
                           label = "Import les datas")
            ),
            box(
              uiOutput("filtreUI"),
              uiOutput("stationUI"),
              checkboxInput("prime", "isPrime ?", value = FALSE, width = NULL),
              actionButton(inputId = "filter", 
                           label = "Filtre les datas")
            )
          )
  ),
  tabItem(tabName = "widgets",
          fluidRow(
            
            box(
              title = "Controls",
              uiOutput("scatterUI"),
              useShinyjs(),
              extendShinyjs(text = jscode, functions = c("closeWindow"))
            ),
            box(
              plotOutput("scatterPlot")
            )
          )
  ),
  tabItem(tabName = "bar",
            fluidRow(
                plotOutput("bar")
            )
  ),
  tabItem(tabName = "stats",
          fluidRow(
            box(plotOutput("distPlot", height = 250)),
            
            box(
              title = "Controls",
              sliderInput("bins", "Number of observations:", 1, 100, 50)
            )
          )
  )
)

dashboardPage(
  
  dashboardHeader(title = "Media",
                  tags$li(class = "dropdown",
                          tags$li(class = "dropdown",
                                  actionButton("close", "", icon("power-off"),
                                               style="color: #fff;height: 50px;text-align: center;border-radius:50%;
                                               width: 50px; background-color: #f06292; border-color: #f06292")))
                                  ),
  
  dashboardSidebar(
    sidebarMenu(
      menuItem("Dashboard", tabName = "dashboard", icon = icon("dashboard")),
      menuItem("Widgets", tabName = "widgets", icon = icon("area-chart")),
      menuItem("Station Barplots", tabName = "bar", icon = icon("bar-chart")),
      menuItem("Stats", tabName = "stats", icon = icon("th"))
    )
  ),
  
  dashboardBody(body)
)

