library(shinydashboard)
library(shinyjs)

jscode <- "shinyjs.closeWindow = function() { window.close(); }"

body <- tabItems(
  tabItem(tabName = "dashboard",
          fluidRow(
            box(
              title = "Controls",
              dateInput("date","Date à traiter",value = "2017-11-15",min="2017-08-01",
                        max="2017-12-31"),
              actionButton(inputId = "import", 
                           label = "Import les datas")
            ),
            box(
              uiOutput("filtreUI"),
              uiOutput("stationUI"),
              actionButton(inputId = "filter", 
                           label = "Filtre les datas")
            )
          )
  ),
  tabItem(tabName = "widgets",
          fluidRow(
            
            box(
              title = "Controls",
              sliderInput("bins", "Number of observations:", 1, 100, 50),
              useShinyjs(),
              extendShinyjs(text = jscode, functions = c("closeWindow"))
            )
          )
  ),
  tabItem(tabName = "stats",
          fluidRow(
            box(plotOutput("distPlot", height = 250)),
            
            box(
              title = "Controls",
              sliderInput("bins", "Number of observations:", 1, 100, 50)
            )
          )
  )
)

dashboardPage(
  
  dashboardHeader(title = "Media",
                  tags$li(class = "dropdown",
                          tags$li(class = "dropdown",
                                  actionButton("close", "", icon("power-off"),
                                               style="color: #fff;height: 50px;text-align: center;border-radius:50%;
                                               width: 50px; background-color: #f06292; border-color: #f06292")))
                                  ),
  
  dashboardSidebar(
    sidebarMenu(
      menuItem("Dashboard", tabName = "dashboard", icon = icon("dashboard")),
      menuItem("Widgets", tabName = "widgets", icon = icon("th")),
      menuItem("Stats", tabName = "stats", icon = icon("th"))
    )
  ),
  
  dashboardBody(body)
)

