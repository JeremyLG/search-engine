library(shiny)
library(ggplot2)
library(sparklyr)
library(sparkavro)
library(dplyr)
library(stringr)

source("../feature_engineering.R",chdir=T)

#spark_disconnect_all()
#Sys.setenv("HADOOP_HOME" = "C:/Users/X170058/AppData/Local/spark/spark-1.6.1-bin-hadoop2.6/tmp/hadoop")
#sc <- spark_connect(master = "local",version="1.6.1")
path <- "C:/Users/X170058/Downloads/audiences.avro"
df <- spark_read_avro(sc, "test_table", path)

shinyServer(function(input, output) {
  
  v <- reactiveValues(data = NULL,df_final = NULL,df_total = NULL)
  
  observeEvent(input$import, {
  
    v$df_final <- calcul_df(df)
    v$data <- (v$df_final %>% collect())[1:500,]
    v$df_total <- v$df_final
    
    })
  
  output$filtreUI <- renderUI({
    if(!is.null(v$df_total)){
    selectInput("target","Spécifiques targets",choices = v$df_total %>% 
                  distinct(target) %>% collect() %>% .[[1]],
                multiple = TRUE)
    }
  })
  
  output$stationUI <- renderUI({
    if(!is.null(v$df_total)){
      selectInput("station","Spécifiques stations",choices = v$df_total %>% 
                    distinct(station) %>% collect() %>% .[[1]],
                  multiple = TRUE)
    }
  })
  
  observeEvent(input$filter, {
    if(!is.null(input$target)){
    targets <- input$target
    v$df_final <- v$df_total %>% filter(target %in% targets)
    v$data <- (v$df_final %>% collect())[1:500,]
    }
  })
  
  output$distPlot <- renderPlot({
    if(!is.null(v$data)){
    print(ggplot(data=v$data,aes(target,partAudience)) + geom_point())
    }
  })
  
  observeEvent(input$close, {
    js$closeWindow()
    stopApp()
  })
})
