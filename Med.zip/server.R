library(shiny)
library(ggplot2)
library(sparklyr)
library(sparkavro)
library(dplyr)
library(stringr)

source("../feature_engineering.R",chdir=T)

#spark_disconnect_all()
Sys.setenv("HADOOP_HOME" = "C:/Users/X170058/AppData/Local/spark/spark-1.6.1-bin-hadoop2.6/tmp/hadoop")
sc <- spark_connect(master = "local",version="1.6.1")
path <- "C:/Users/X170058/Downloads/audiences.avro"
df <- spark_read_avro(sc, "test_table", path)

shinyServer(function(input, output) {
  
  v <- reactiveValues(data = NULL,df_final = NULL,df_total = NULL)
  
  observeEvent(input$import, {
  
    v$df_final <- calcul_df(df)
    v$data <- (v$df_final %>% collect())[1:500,]
    v$df_total <- v$df_final
    
    })
  
  output$filtreUI <- renderUI({
    if(!is.null(v$df_total)){
    selectInput("target","Specifiques targets",choices = v$df_total %>% 
                  distinct(target) %>% collect() %>% .[[1]],
                multiple = TRUE)
    }
  })
  
  output$stationUI <- renderUI({
    if(!is.null(v$df_total)){
      selectInput("station","Specifiques stations",choices = v$df_total %>% 
                    distinct(station) %>% collect() %>% .[[1]],
                  multiple = TRUE)
    }
  })
  
  observeEvent(input$filter, {
    if(!is.null(input$target) & !is.null(input$station)){
    targets <- input$target
    stations <- input$station
    v$df_final <- v$df_total %>% filter(target %in% targets & station %in% stations)
    if(input$prime){
      v$df_final <- v$df_final %>% filter(isPrime == 1)
    }
    v$data <- (v$df_final %>% collect())[1:500,]
    }
  })
  
  output$distPlot <- renderPlot({
    if(!is.null(v$data)){
    p <- ggplot(data=v$data,aes(target,partAudience)) + geom_point()
    print(p)
    }
  })
  
  output$histPlot <- renderPlot({
    p <- ggplot(data=chol, aes(chol$AGE)) + 
      geom_histogram(aes(y =..density..), 
                     breaks=seq(20, 50, by = 2), 
                     col="red", 
                     fill="green", 
                     alpha = .2) + 
      geom_density(col=2) + 
      labs(title="Histogram for Age") +
      labs(x="Age", y="Count")
  })
  
  output$scatterPlot <- renderPlot({
    x <- input$x_scatter
    y <- input$y_scatter
    if(!is.null(input$x_scatter) & !is.null(input$y_scatter) & !is.null(v$data)){
    p <- ggplot(v$data,aes(x=v$data[,x]/60,y=v$data[,y])) +
      geom_point(aes(col=target, size=effectif)) + 
      geom_smooth(method="loess", se=F) + 
      xlim(c(0, max(v$data[,x])/60)) + 
      ylim(c(0, max(v$data[,y]))) + 
      labs(subtitle= paste0(x,"Vs.",y), 
           y=y, 
           x=x, 
           title="Scatterplot", 
           caption = "Source: Medias")
    print(p)
    }
  })
  
  output$scatterUI <- renderUI({
    if(!is.null(v$df_total)){
      list(selectInput("x_scatter","Select x",choices = names(which(sapply(v$data,is.numeric))),selected="duree"),
      selectInput("y_scatter","Select y",choices = names(which(sapply(v$data,is.numeric))),selected="audienceRate"))
    }
  })
  
  output$bar <- renderPlot({
    
    mean_part <- v$df_final %>%
      group_by(station,target) %>%
      summarise_at(vars(partAudience),funs(n(),mean(.,na.rm = T)))
    
    p <- ggplot(mean_part %>% collect(),aes(target,mean,fill=target)) +
      facet_grid(. ~ station) + geom_bar(stat="identity") +
      theme(axis.text.x = element_text(angle = 90, hjust = 1))+
      theme(strip.background = element_rect(fill="darkblue"),
            strip.text.x = element_text(size = 12,face="bold", colour = "orange")) +
      theme(axis.text=element_text(size=12),
            axis.title=element_text(size=14,face="bold"))
    print(p)
    
  })
  observeEvent(input$close, {
    js$closeWindow()
    stopApp()
  })
})
