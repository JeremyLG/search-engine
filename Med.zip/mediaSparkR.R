
if (nchar(Sys.getenv("SPARK_HOME")) < 1) {
  Sys.setenv(SPARK_HOME = "C:/Users/X170058/AppData/Local/spark/spark-2.2.0-bin-hadoop2.7")
}
Sys.getenv("SPARK_HOME")
Sys.getenv("HADOOP_HOME")
Sys.setenv(HADOOP_HOME = "C:/Users/X170058/Downloads/hadoop")

library(SparkR, lib.loc = c(file.path(Sys.getenv("SPARK_HOME"), "R", "lib")))
sparkR.session(master = "local[*]", 
               sparkConfig = list( spark.sql.warehouse.dir ="C:/tmp/hive",
                                   spark.driver.memory = "2g"))#,
               #sparkPackages = c("C:/Users/X170058/.m2/repository/com/databricks/spark-avro_2.11/4.0.0/spark-avro_2.11-4.0.0.jar")#,
               #sparkPackages = c("com.databricks:spark-avro_2.11:4.0.0")
               #)
path <- "C:/Users/X170058/Downloads/audiences.avro"
path <- "C:/Users/X170058/Downloads/tt/file.csv"
df <- read.df(path,"csv", header = "true", inferSchema = "true", na.strings = "NA")

show(df)

head(df)

df_Tv <- df %>%
  SparkR::filter(
    (df$station != "Total TV") &
      (df$programType == "A") &
      (df$level == 1) &
      (df$sectionned == 0)
  ) %>%
  SparkR::select(c("station","target","broadId","show","beginHour",
                   "endHour","dureeReelle","audienceRate","extrapolated"))

df_totalTv <- df %>%
  SparkR::filter(df$station == "Total TV") %>%
  SparkR::withColumnRenamed("station","stationTTv") %>%
  SparkR::withColumnRenamed("target","targetTTv") %>%
  SparkR::withColumnRenamed("broadId","broadIdTTv") %>%
  SparkR::withColumnRenamed("audienceRate","audienceRateTTv") %>%
  SparkR::select(c("stationTTv","targetTTv","broadIdTTv","audienceRateTTv"))
head(df_totalTv)

df_join <- df_Tv %>%
  SparkR::join(df_totalTv,df_Tv$broadId == df_totalTv$broadIdTTv & df_Tv$target == df_totalTv$targetTTv) %>%
  SparkR::drop("stationTTv")
head(df_join)

df1 <- df_join %>%
  SparkR::dapply(function(x) { x <- toTime(x) },schema) %>%
  SparkR::dapply(function(x) { x <- toTimeEnd(x) },schema) %>%
  SparkR::dapply(function(x) {
  x <- cbind(x, "partAudience" = partAudience(x$audienceRate,x$extrapolated))
},schema)

df_join %>%
  SparkR::dapply(function(x) {
  x <- cbind(x, "partAudience" = partAudience(as.data.frame(x)))
},schema) %>%
SparkR::collect()

df_join %>%
  SparkR::dapplyCollect(function(x) {
    x <- partAudience(x)
  })

partAudience(as.data.frame(df_join))

df_join$audienceRate
schema <- SparkR::schema(df_join)
df1 <- dapplyCollect(df_join, function(p) { partAudience(p$audienceRate,p$audienceRateTTv) })

dff <- SparkR::collect(df)

toTime <- function(df){
  tr <- as.character(df$beginHour)
  h_a <- stringr::str_sub(tr,0,2)
  n_a <- as.integer(h_a)
  ch <- n_a %% 24
  df$beginHour <- ifelse(n_a>=24,paste0(0,ch,stringr::str_sub(tr,3)),tr)
  return(df)
} 
toTimeEnd <- function(df){
  tr <- as.character(df$endHour)
  h_a <- stringr::str_sub(tr,0,2)
  n_a <- as.integer(h_a)
  ch <- n_a %% 24
  df$endHour <- ifelse(n_a>=24,paste0(0,ch,stringr::str_sub(tr,3)),tr)
  return(df)
} 

effectifTouche <- function(audience, extrapolated){
  TM = audience / 1000000
  VE= extrapolated/100
  TME = TM * VE
  nbVis = TME / 1000000.1
  return (nbVis)
}

partAudience <- function(test){
  return(ifelse(test$audienceRateTTv != 0,test$audienceRate/test$audienceRateTTv*100,0))
  
}

partAudience(test)

toTime <- function(hour){
  res <-  as.character(hour)
  h_a <- str_sub(res,0,2)
  n = as.integer(h_a)
  if(n >= 24){
    res <- paste0(0,n-24,str_sub(res,3))
  }
  return(res)   
}


durationInSec <- function(df){
  dd <- strptime(df$endHour, format="%H:%M:%S")-strptime(df$beginHour, format="%H:%M:%S")
  return(as.numeric(dd,units="secs"))
}

isPrimeTime <- function(beginHour,duree){
  return((beginHour > "20:30:00")&(beginHour < "22:00:00")&(as.integer(duree) > 1800))
}

test <- dff[1:450,]
dd <- strptime(test$endHour, format="%H:%M:%S")-strptime(test$beginHour, format="%H:%M:%S")
  as.numeric(dd,units="secs")
  
  res <- 0
  if(test$audienceRateTTv != 0){
    res <- test$audienceRate/test$audienceRateTTv*100
  }

  ifelse(test$audienceRateTTv != 0,test$audienceRate/test$audienceRateTTv*100,0)
colnames(dff)
test <- dff[1:500,]
dff <- df_join%>%SparkR::collect()
sparkR.session.stop()

