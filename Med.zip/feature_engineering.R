calcul_df <- function(df){
  df_Tv <- df %>%
    filter(
      (station != "Total TV") &
        (programType == "A") &
        (level == 1) &
        (sectionned == 0)
      #(target %in% "Ind4+") &
      #(dureeReelle != 0)
    ) %>%
    select(c("station","target","broadId","show","beginHour","endHour","dureeReelle","audienceRate","extrapolated"))
  #select(c("station","target","broadId","show","prefix","kind","beginHour","endHour","dureeReelle","audienceRate","extrapolated"))
  
  df_totalTv <- df %>%
    filter(station == "Total TV") %>%
    select(stationTTv=station,targetTTv=target,broadIdTTv=broadId,audienceRateTTv=audienceRate)
  
  
  df_join <- df_Tv %>%
    left_join(df_totalTv,by = c("broadId"="broadIdTTv","target"="targetTTv")) %>%
    select(-stationTTv)
  
  df_final <- df_join %>%
    mutate(TM = audienceRate / 1000000,
           VE = extrapolated / 100,
           TME = TM * VE) %>%
    mutate(effectif = TME / 1000000.1) %>%
    select(-c(TM,VE,TME)) %>%
    mutate(duree = hour(endHour)*3600 + minute(endHour)*60 + second(endHour) -
             hour(beginHour)*3600 - minute(beginHour)*60 - second(beginHour)) %>%
    mutate(isPrime = beginHour > "20:30:00" & beginHour < "22:00:00" & duree > 1800) %>%
    mutate(partAudience = audienceRate/audienceRateTTv*100) %>%
    na.replace(partAudience = 0) %>%
    select(c("station","target","broadId","show","beginHour","endHour","duree","audienceRate","extrapolated","audienceRateTTv","effectif","isPrime","partAudience"))
  return(df_final)
}
